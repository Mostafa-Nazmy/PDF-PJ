# backend/app.py

import os
import tempfile
import io  # Import the BytesIO module for in-memory file handling
from flask import Flask, request, jsonify, send_from_directory
import fitz # PyMuPDF
import base64
from hdfs import InsecureClient # <-- NEW: Import the HDFS client library

app = Flask(__name__, static_folder='../frontend', static_url_path='/')

# --- NEW: HDFS Configuration ---
# IMPORTANT: Update these with your HDFS cluster's NameNode host and port.
# The default HDFS web UI port is 50070.
HDFS_HOST = 'your_hdfs_namenode_hostname_or_ip' # e.g., '192.168.1.100' or 'localhost'
HDFS_PORT = 50070 # Or the port for your HDFS Web HDFS API
HDFS_USER = 'your_hdfs_username' # Optional, specify if authentication is needed

# --- Existing Configuration ---
# This folder is now only used for the file upload feature.
PDF_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'pdfs')
if not os.path.exists(PDF_FOLDER):
    os.makedirs(PDF_FOLDER)

ALLOWED_EXTENSIONS = {'pdf'}

def allowed_file(filename):
    """Check if the uploaded file has an allowed extension."""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def process_pdf_to_images(file_stream):
    """
    Core function to convert a PDF from a byte stream into base64 encoded PNG images.
    
    This function is now more flexible, accepting a stream (BytesIO object)
    or a file path.
    """
    try:
        # fitz.open() can take a stream/bytes object directly.
        # We specify the filetype to help it recognize the data as a PDF.
        doc = fitz.open(stream=file_stream, filetype="pdf")
        image_pages = []
        for page_num in range(doc.page_count):
            page = doc.load_page(page_num)
            pix = page.get_pixmap()
            img_bytes = pix.pil_tobytes(format="PNG")
            base64_image = base64.b64encode(img_bytes).decode('utf-8')
            image_pages.append(base64_image)
        doc.close()
        return image_pages
    except Exception as e:
        print(f"Error processing PDF from stream: {e}")
        return None

# --- Routes for serving static files ---

@app.route('/')
def serve_index():
    """Serves the main HTML file for the frontend."""
    return send_from_directory(app.static_folder, 'index.html')

@app.route('/<path:filename>')
def serve_static(filename):
    """Serves other static files (CSS, JS)."""
    return send_from_directory(app.static_folder, filename)

# --- MODIFIED: API Endpoint to load a PDF from the HDFS server ---

@app.route('/pdf_images/<path:pdf_filename>', methods=['GET'])
def get_pdf_images(pdf_filename):
    """
    Connects to HDFS, retrieves the specified PDF file's content,
    and converts it to images.
    """
    try:
        # NEW: Create an HDFS client instance
        # In a production environment, you might want to reuse this client connection.
        client = InsecureClient(f'http://{HDFS_HOST}:{HDFS_PORT}', user=HDFS_USER)

        # NEW: Read the file content from HDFS directly into a BytesIO object
        # The 'read' method returns a file-like object that can be read from.
        with client.read(pdf_filename, encoding=None) as reader:
            pdf_bytes = io.BytesIO(reader.read())
            
        # Process the in-memory PDF data
        images = process_pdf_to_images(pdf_bytes)

        if images is None:
            return jsonify({"error": "Failed to process PDF from HDFS."}), 500
        
        return jsonify({"images": images})

    except Exception as e:
        # A 404 error from HDFS will be caught here as well.
        print(f"Error retrieving/processing PDF from HDFS: {e}")
        return jsonify({"error": f"Error accessing PDF from HDFS. Check filename or HDFS connection. ({e})"}), 500

# --- Existing API Endpoint for uploading a PDF from the user's computer ---

@app.route('/upload_pdf', methods=['POST'])
def upload_pdf():
    """
    Receives a PDF file from the user's computer, processes it, and returns images.
    This still uses a local temporary file for processing.
    """
    if 'pdf_file' not in request.files:
        return jsonify({"error": "No file part in the request."}), 400
    
    file = request.files['pdf_file']
    
    if file.filename == '':
        return jsonify({"error": "No file selected."}), 400

    if file and allowed_file(file.filename):
        # Read the uploaded file's content into memory.
        # This is more efficient for our use case than saving to disk.
        file_stream = io.BytesIO(file.read())
        
        images = process_pdf_to_images(file_stream)
        if images is None:
            return jsonify({"error": "Failed to process the uploaded PDF."}), 500
        
        return jsonify({"images": images})
    else:
        return jsonify({"error": "Invalid file type. Only PDF files are allowed."}), 400

# --- Main execution block ---

if __name__ == '__main__':
    app.run(debug=True, host='127.0.0.1', port=5000)