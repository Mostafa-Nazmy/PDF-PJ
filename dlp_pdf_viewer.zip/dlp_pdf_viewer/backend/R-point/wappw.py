# backend/app.py

import os
import tempfile
from flask import Flask, request, jsonify, send_from_directory
import fitz # PyMuPDF
import base64

app = Flask(__name__, static_folder='../frontend', static_url_path='/')

# Define the folder where your server-side PDF files are stored
PDF_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'pdfs')

# Ensure the PDF folder exists
if not os.path.exists(PDF_FOLDER):
    os.makedirs(PDF_FOLDER)

# Define allowed file extensions for security
ALLOWED_EXTENSIONS = {'pdf'}

def allowed_file(filename):
    """Check if the uploaded file has an allowed extension."""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def process_pdf_to_images(file_path):
    """
    Core function to convert a PDF into a series of base64 encoded PNG images.
    """
    try:
        doc = fitz.open(file_path)
        image_pages = []
        for page_num in range(doc.page_count):
            page = doc.load_page(page_num)
            pix = page.get_pixmap()
            img_bytes = pix.pil_tobytes(format="PNG")
            base64_image = base64.b64encode(img_bytes).decode('utf-8')
            image_pages.append(base64_image)
        doc.close()
        return image_pages
    except Exception as e:
        # Log the error for debugging
        print(f"Error processing PDF file '{file_path}': {e}")
        return None

# --- Routes for serving static files ---

@app.route('/')
def serve_index():
    """Serves the main HTML file for the frontend."""
    return send_from_directory(app.static_folder, 'index.html')

@app.route('/<path:filename>')
def serve_static(filename):
    """Serves other static files (CSS, JS)."""
    return send_from_directory(app.static_folder, filename)

# --- API Endpoint to load a PDF from the server's directory ---

@app.route('/pdf_images/<pdf_filename>', methods=['GET'])
def get_pdf_images(pdf_filename):
    """
    Converts a PDF from the server's 'pdfs' folder to images.
    """
    pdf_path = os.path.join(PDF_FOLDER, pdf_filename)
    if not os.path.exists(pdf_path):
        return jsonify({"error": f"PDF file '{pdf_filename}' not found on the server."}), 404

    images = process_pdf_to_images(pdf_path)
    if images is None:
        return jsonify({"error": "Failed to process PDF from server."}), 500
    
    return jsonify({"images": images})

# --- NEW API Endpoint for uploading a PDF from the user's computer ---

@app.route('/upload_pdf', methods=['POST'])
def upload_pdf():
    """
    Receives a PDF file from the user's computer, processes it, and returns images.
    """
    # Check if the 'pdf_file' part is in the request.
    if 'pdf_file' not in request.files:
        return jsonify({"error": "No file part in the request."}), 400
    
    file = request.files['pdf_file']
    
    # Check if a file was selected.
    if file.filename == '':
        return jsonify({"error": "No file selected."}), 400

    # Check if the file is a PDF and process it.
    if file and allowed_file(file.filename):
        # Use a temporary file to avoid saving user files permanently.
        # This is crucial for security and privacy.
        with tempfile.NamedTemporaryFile(delete=False, suffix='.pdf') as temp_file:
            temp_path = temp_file.name
            file.save(temp_path) # Save the uploaded file to the temporary path

        try:
            images = process_pdf_to_images(temp_path)
            if images is None:
                return jsonify({"error": "Failed to process the uploaded PDF."}), 500
            
            return jsonify({"images": images})

        finally:
            # Always delete the temporary file after processing.
            os.unlink(temp_path)
    else:
        return jsonify({"error": "Invalid file type. Only PDF files are allowed."}), 400

# --- Main execution block ---

if __name__ == '__main__':
    app.run(debug=True, host='127.0.0.1', port=5000)